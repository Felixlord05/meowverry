import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { PawCursor } from "@/components/PawCursor";
import { PawParticles } from "@/components/PawParticles";
import { HeroCat } from "@/components/HeroCat";
import { CatCard } from "@/components/CatCard";
import { Reveal } from "@/components/Reveal";
import { Scene3D } from "@/components/Scene3D";
import cat1 from "@/assets/cat-1.png";
import cat2 from "@/assets/cat-2.png";
import cat3 from "@/assets/cat-3.png";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Meowverse — Thế giới của những chú mèo tinh nghịch" },
      {
        name: "description",
        content:
          "Khám phá thế giới ấm áp của những chú mèo tinh nghịch: chân dung, tính cách và những khoảnh khắc đáng yêu nhất.",
      },
    ],
  }),
});

const cats = [
  {
    image: cat1,
    name: "Miu Cuộn Len",
    trait: "Tò mò",
    description:
      "Một quả bóng len cũng đủ làm Miu vui cả buổi chiều. Đôi mắt xanh long lanh và những cú vồ vụng về.",
  },
  {
    image: cat2,
    name: "Bông Ngủ Ngày",
    trait: "Lười biếng",
    description:
      "Ngủ 18 tiếng mỗi ngày là chuyện bình thường. Bông là chuyên gia trong việc tìm chỗ nắng ấm nhất nhà.",
  },
  {
    image: cat3,
    name: "Mun Phi Hành Gia",
    trait: "Tinh nghịch",
    description:
      "Bay nhảy khắp nhà, leo trèo mọi nơi. Không có cái kệ nào là an toàn khi Mun đang ở chế độ phấn khích.",
  },
];

function Index() {
  return (
    <main className="relative min-h-screen overflow-x-hidden text-foreground">
      {/* 3D parallax scene + floating paws + custom cursor */}
      <Scene3D />
      <PawParticles />
      <PawCursor />

      {/* ===== Navigation ===== */}
      <nav className="glass sticky top-4 z-30 mx-auto mt-4 flex max-w-7xl items-center justify-between rounded-full px-6 py-3">
        <div className="font-display flex items-center gap-2 text-2xl font-bold">
          <span className="wiggle inline-block">🐱</span>
          <span>Meowverse</span>
        </div>
        <div className="hidden items-center gap-8 text-sm font-semibold md:flex">
          <a data-hover href="#cats" className="transition-colors hover:text-primary">
            Bộ sưu tập
          </a>
          <a data-hover href="#facts" className="transition-colors hover:text-primary">
            Sự thật
          </a>
          <a
            data-hover
            href="#join"
            className="rounded-full bg-primary px-5 py-2.5 text-primary-foreground shadow-[var(--shadow-glow)] transition-transform hover:scale-105"
          >
            Tham gia
          </a>
        </div>
      </nav>

      {/* ===== Hero ===== */}
      <section className="relative z-10 mx-auto grid min-h-[80vh] max-w-7xl grid-cols-1 items-center gap-8 px-6 pb-20 pt-10 md:grid-cols-2">
        <div className="relative z-10">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="glass inline-block rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-primary"
          >
            🐾 Chào mừng tới Meowverse
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="font-display mt-5 text-5xl font-bold leading-[1.05] md:text-7xl"
          >
            Thế giới của những{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              chú mèo
            </span>{" "}
            tinh nghịch
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-6 max-w-lg text-lg text-muted-foreground"
          >
            Bước vào một vũ trụ ấm áp, nơi mỗi chú mèo có một câu chuyện riêng — từ
            những cú vồ vụng về tới những giấc ngủ trưa thiên thần.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-8 flex flex-wrap gap-4"
          >
            <a
              data-hover
              href="#cats"
              className="rounded-full bg-primary px-7 py-3.5 font-bold text-primary-foreground shadow-[var(--shadow-glow)] transition-transform hover:scale-105"
            >
              Khám phá ngay 🐾
            </a>
            <a
              data-hover
              href="#facts"
              className="glass rounded-full px-7 py-3.5 font-bold transition-transform hover:scale-105"
            >
              Sự thật thú vị
            </a>
          </motion.div>
        </div>

        {/* Peeking hero cat */}
        <div className="relative h-[400px] md:h-[600px]">
          <HeroCat />
        </div>
      </section>

      {/* ===== Cat collection ===== */}
      <section id="cats" className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <Reveal className="mx-auto max-w-2xl text-center">
          <h2 className="font-display text-4xl font-bold md:text-5xl">
            Gặp gỡ các nhân vật chính
          </h2>
          <p className="mt-4 text-muted-foreground">
            Mỗi chú mèo đều có một tính cách độc nhất. Di chuột vào để nghe các bé
            nói "meo meo"!
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {cats.map((c, i) => (
            <Reveal key={c.name} delay={i * 0.12}>
              <CatCard {...c} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* ===== Fun facts (Bento grid) ===== */}
      <section id="facts" className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <Reveal className="mb-12 text-center">
          <h2 className="font-display text-4xl font-bold md:text-5xl">
            Những điều kỳ diệu về mèo
          </h2>
        </Reveal>

        <div className="grid auto-rows-[180px] grid-cols-1 gap-5 md:grid-cols-4">
          <Reveal className="md:col-span-2 md:row-span-2">
            <div
              data-hover
              className="flex h-full flex-col justify-between rounded-3xl bg-gradient-to-br from-primary to-accent p-8 text-primary-foreground shadow-[var(--shadow-soft)]"
            >
              <span className="text-6xl">😴</span>
              <div>
                <div className="font-display text-5xl font-bold">70%</div>
                <p className="mt-2 opacity-90">
                  cuộc đời của một chú mèo dành cho việc ngủ — và chúng ngủ rất giỏi.
                </p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <div
              data-hover
              className="glass flex h-full flex-col justify-between rounded-3xl p-6"
            >
              <span className="text-4xl">👃</span>
              <div>
                <div className="font-display text-3xl font-bold">200M</div>
                <p className="text-sm text-muted-foreground">tế bào khứu giác</p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.2}>
            <div
              data-hover
              className="glass flex h-full flex-col justify-between rounded-3xl p-6"
            >
              <span className="text-4xl">🦘</span>
              <div>
                <div className="font-display text-3xl font-bold">2m</div>
                <p className="text-sm text-muted-foreground">độ cao có thể nhảy</p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.3} className="md:col-span-2">
            <div
              data-hover
              className="glass flex h-full items-center gap-5 rounded-3xl p-6"
            >
              <span className="text-5xl">🎵</span>
              <div>
                <div className="font-display text-2xl font-bold">Tiếng "purr"</div>
                <p className="text-sm text-muted-foreground">
                  có tần số 25-150Hz — được cho là có khả năng chữa lành.
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ===== CTA ===== */}
      <section id="join" className="relative z-10 mx-auto max-w-4xl px-6 py-24">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-accent via-primary to-accent p-12 text-center text-primary-foreground shadow-[var(--shadow-glow)] md:p-16">
            <div className="absolute -right-10 -top-10 text-9xl opacity-20">🐾</div>
            <div className="absolute -bottom-10 -left-10 text-9xl opacity-20">🐾</div>
            <h2 className="font-display text-4xl font-bold md:text-5xl">
              Sẵn sàng gia nhập đại gia đình mèo?
            </h2>
            <p className="mx-auto mt-4 max-w-xl opacity-90">
              Đăng ký nhận bản tin hàng tuần với những câu chuyện, ảnh và mẹo chăm
              sóc mèo dễ thương nhất.
            </p>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
            >
              <input
                type="email"
                required
                placeholder="email@cua-ban.com"
                className="flex-1 rounded-full bg-background/95 px-5 py-3.5 text-foreground outline-none ring-2 ring-transparent focus:ring-background"
              />
              <button
                data-hover
                type="submit"
                className="rounded-full bg-foreground px-6 py-3.5 font-bold text-background transition-transform hover:scale-105"
              >
                Đăng ký 🐱
              </button>
            </form>
          </div>
        </Reveal>
      </section>

      {/* ===== Footer ===== */}
      <footer className="relative z-10 mx-auto max-w-7xl px-6 py-10 text-center text-sm text-muted-foreground">
        <p>
          Made with <span className="text-accent">♥</span> & 🐾 — Meowverse {new Date().getFullYear()}
        </p>
      </footer>
    </main>
  );
}
