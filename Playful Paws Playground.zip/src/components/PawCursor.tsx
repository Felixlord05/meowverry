import { useEffect, useState } from "react";
import { motion } from "framer-motion";

/**
 * Custom paw-shaped cursor that follows the mouse.
 */
export function PawCursor() {
  const [pos, setPos] = useState({ x: -100, y: -100 });
  const [hover, setHover] = useState(false);

  useEffect(() => {
    const move = (e: MouseEvent) => setPos({ x: e.clientX, y: e.clientY });
    const over = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      setHover(!!t.closest("a,button,[data-hover]"));
    };
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseover", over);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseover", over);
    };
  }, []);

  return (
    <motion.div
      className="pointer-events-none fixed z-[9999] text-2xl"
      animate={{ x: pos.x - 12, y: pos.y - 12, scale: hover ? 1.6 : 1 }}
      transition={{ type: "spring", stiffness: 500, damping: 28, mass: 0.3 }}
      style={{ filter: "drop-shadow(0 2px 4px rgba(0,0,0,.2))" }}
    >
      🐾
    </motion.div>
  );
}
