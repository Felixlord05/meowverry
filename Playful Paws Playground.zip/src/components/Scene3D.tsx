import { useEffect } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";

/**
 * Lightweight pseudo-3D background scene.
 * Uses CSS perspective + parallax depth layers that react to the cursor
 * to give the illusion of a 3D space behind the hero — no Three.js payload.
 */
type Orb = {
  size: number;
  x: string;
  y: string;
  depth: number; // 0 = far, 1 = near (controls parallax strength + blur)
  color: string;
};

const ORBS: Orb[] = [
  { size: 520, x: "10%", y: "15%", depth: 0.15, color: "oklch(0.85 0.15 50 / 0.55)" },
  { size: 380, x: "75%", y: "20%", depth: 0.35, color: "oklch(0.82 0.16 25 / 0.55)" },
  { size: 260, x: "20%", y: "70%", depth: 0.55, color: "oklch(0.88 0.12 80 / 0.55)" },
  { size: 200, x: "80%", y: "75%", depth: 0.7, color: "oklch(0.78 0.18 45 / 0.55)" },
  { size: 140, x: "55%", y: "45%", depth: 0.9, color: "oklch(0.92 0.10 30 / 0.5)" },
];

export function Scene3D() {
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 220, damping: 28, mass: 0.4 });
  const sy = useSpring(my, { stiffness: 220, damping: 28, mass: 0.4 });

  // Subtle whole-scene tilt for added depth illusion
  const rotY = useTransform(sx, (v) => v * 6);
  const rotX = useTransform(sy, (v) => v * -6);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      mx.set((e.clientX / window.innerWidth) * 2 - 1);
      my.set((e.clientY / window.innerHeight) * 2 - 1);
    };
    window.addEventListener("mousemove", handler);
    return () => window.removeEventListener("mousemove", handler);
  }, [mx, my]);

  return (
    <div
      className="pointer-events-none fixed inset-0 z-0 overflow-hidden"
      style={{ perspective: "1200px" }}
    >
      <motion.div
        className="absolute inset-0"
        style={{
          rotateX: rotX,
          rotateY: rotY,
          transformStyle: "preserve-3d",
        }}
      >
        {ORBS.map((orb, i) => (
          <Orb key={i} orb={orb} sx={sx} sy={sy} />
        ))}

        {/* Soft grid floor for depth cue */}
        <div
          className="absolute inset-x-0 bottom-0 h-[60vh] opacity-[0.07]"
          style={{
            backgroundImage:
              "linear-gradient(oklch(0.3 0.1 40) 1px, transparent 1px), linear-gradient(90deg, oklch(0.3 0.1 40) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
            transform: "rotateX(70deg) translateZ(-100px)",
            transformOrigin: "bottom",
            maskImage:
              "linear-gradient(to top, black 20%, transparent 90%)",
          }}
        />
      </motion.div>
    </div>
  );
}

function Orb({
  orb,
  sx,
  sy,
}: {
  orb: Orb;
  sx: ReturnType<typeof useSpring>;
  sy: ReturnType<typeof useSpring>;
}) {
  const range = 80 * orb.depth;
  const x = useTransform(sx, (v) => v * range);
  const y = useTransform(sy, (v) => v * range);
  const z = (orb.depth - 0.5) * 200;

  return (
    <motion.div
      className="absolute rounded-full"
      style={{
        left: orb.x,
        top: orb.y,
        width: orb.size,
        height: orb.size,
        x,
        y,
        translateZ: z,
        background: `radial-gradient(circle at 30% 30%, ${orb.color}, transparent 70%)`,
        filter: `blur(${(1 - orb.depth) * 30 + 10}px)`,
      }}
    />
  );
}
