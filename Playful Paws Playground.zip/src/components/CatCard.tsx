import { useState } from "react";
import { motion } from "framer-motion";

interface CatCardProps {
  image: string;
  name: string;
  trait: string;
  description: string;
}

/**
 * Info card with hover zoom on image and a playful "meo meo!" speech bubble.
 */
export function CatCard({ image, name, trait, description }: CatCardProps) {
  const [hover, setHover] = useState(false);

  return (
    <motion.article
      data-hover
      onHoverStart={() => setHover(true)}
      onHoverEnd={() => setHover(false)}
      whileHover={{ y: -8 }}
      transition={{ type: "spring", stiffness: 250, damping: 20 }}
      className="glass group relative overflow-hidden rounded-3xl p-6"
    >
      {/* Speech bubble */}
      <motion.div
        initial={{ opacity: 0, scale: 0.6, y: 10 }}
        animate={hover ? { opacity: 1, scale: 1, y: 0 } : { opacity: 0, scale: 0.6, y: 10 }}
        transition={{ type: "spring", stiffness: 400, damping: 16 }}
        className="absolute right-4 top-4 z-20 rounded-2xl bg-accent px-3 py-1.5 text-sm font-bold text-accent-foreground shadow-lg"
      >
        meo meo! 🐱
        <span className="absolute -bottom-1 left-4 h-3 w-3 rotate-45 bg-accent" />
      </motion.div>

      {/* Image */}
      <div className="relative mb-5 aspect-square overflow-hidden rounded-2xl bg-secondary/50">
        <motion.img
          src={image}
          alt={name}
          loading="lazy"
          width={768}
          height={768}
          className="h-full w-full object-contain"
          animate={hover ? { scale: 1.12, rotate: -2 } : { scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 200, damping: 18 }}
        />
      </div>

      <span className="inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary">
        {trait}
      </span>
      <h3 className="font-display mt-3 text-2xl font-bold text-foreground">{name}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{description}</p>
    </motion.article>
  );
}
