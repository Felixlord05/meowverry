import { useEffect, useState } from "react";

/**
 * Background floating paw prints particles. Client-only to avoid SSR mismatch.
 */
export function PawParticles({ count = 18 }: { count?: number }) {
  const [paws, setPaws] = useState<
    { id: number; left: number; size: number; delay: number; duration: number; opacity: number }[]
  >([]);

  useEffect(() => {
    setPaws(
      Array.from({ length: count }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        size: 16 + Math.random() * 28,
        delay: Math.random() * 20,
        duration: 18 + Math.random() * 18,
        opacity: 0.15 + Math.random() * 0.25,
      })),
    );
  }, [count]);

  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {paws.map((p) => (
        <span
          key={p.id}
          className="paw-particle"
          style={{
            left: `${p.left}%`,
            fontSize: `${p.size}px`,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
            opacity: p.opacity,
          }}
        >
          🐾
        </span>
      ))}
    </div>
  );
}
