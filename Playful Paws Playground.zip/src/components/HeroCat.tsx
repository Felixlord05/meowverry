import { useEffect } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import peekingCat from "@/assets/peeking-cat.png";

/**
 * Hero cat that peeks from the right edge and tilts/follows the cursor.
 */
export function HeroCat() {
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 250, damping: 25, mass: 0.4 });
  const sy = useSpring(my, { stiffness: 250, damping: 25, mass: 0.4 });

  const x = useTransform(sx, (v) => v * 30);
  const y = useTransform(sy, (v) => v * 20);
  const rotate = useTransform(sx, (v) => v * -8);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const nx = (e.clientX / window.innerWidth) * 2 - 1;
      const ny = (e.clientY / window.innerHeight) * 2 - 1;
      mx.set(nx);
      my.set(ny);
    };
    window.addEventListener("mousemove", handler);
    return () => window.removeEventListener("mousemove", handler);
  }, [mx, my]);

  return (
    <motion.div
      initial={{ x: 400, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 60, damping: 14, delay: 0.4 }}
      className="pointer-events-none absolute -right-20 bottom-0 z-10 w-[55vw] max-w-[640px] md:-right-10"
      style={{ x, y, rotate }}
    >
      <img
        src={peekingCat}
        alt="Mèo cam tinh nghịch lấp ló"
        width={1024}
        height={1024}
        className="h-auto w-full select-none drop-shadow-[0_30px_60px_rgba(180,80,30,0.35)]"
      />
    </motion.div>
  );
}
